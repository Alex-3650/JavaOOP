package Exercise_04;

public interface Identifiable {

    String getId();
}
