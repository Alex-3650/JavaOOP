package Exercise_03;

public interface Person {
    String getName();
    String sayHello();

}
