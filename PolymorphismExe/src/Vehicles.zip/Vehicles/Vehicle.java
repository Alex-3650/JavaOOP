package Vehicles;

public interface Vehicle {
    String drive(double km);
    void refuel(double liters);
}
