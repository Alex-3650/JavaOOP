package Exercise_06.CAT;

import Exercise_06.Animal;

public class Cat extends Animal {
    public Cat(int age, String gender, String name) {
        super(age, gender, name);
    }
}
